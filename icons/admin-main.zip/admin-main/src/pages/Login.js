import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form, Input, Button, Card, Typography, message } from 'antd';
import axios from 'axios';
import dayjs from 'dayjs';
import { getDoc, doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import './styles/Login.css';

const { Title } = Typography;

const Login = ({ onLogin }) => {
  const [background, setBackground] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Função que gera a saudação baseada na hora do dia
  const getGreetingMessage = (username) => {
    const currentHour = new Date().getHours();
    let greeting;

    if (currentHour < 12) {
      greeting = 'Bom dia';
    } else if (currentHour < 18) {
      greeting = 'Boa tarde';
    } else {
      greeting = 'Boa noite';
    }

    return `${greeting}, ${username}! Bem-vindo(a) de volta!`;
  };

  useEffect(() => {
    const fetchBackground = async () => {
      try {
        const docRef = doc(db, 'appConfig', 'loginBackground');
        const unsubscribe = onSnapshot(docRef, (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data();
            setBackground(data.backgroundUrl);
            console.log('Background atualizado:', data.backgroundUrl);
          } else {
            console.log('Nenhuma configuração de fundo encontrada.');
          }
        });

        return () => unsubscribe();
      } catch (error) {
        console.error('Erro ao carregar o fundo:', error);
      }
    };

    fetchBackground();
  }, []);

  const updateOnlineStatus = async (user, isOnline) => {
    try {
      const now = dayjs().format('YYYY-MM-DD HH:mm:ss');
      const userData = {
        Id: user.id,
        name: user.name,
        email: user.email,
        password: user.password,
        Cargo1: user.Cargo1,
        username: user.username,
        profilePicUrl: user.profilePic,
        isOnline: isOnline,
        lastActiveAt: now,
      };

      console.log('Atualizando status para:', userData);

      const response = await axios.patch(
        'https://nocodb.nexusnerds.com.br/api/v2/tables/mjuogdam2c8ig6l/records',
        userData,
        {
          headers: {
            'xc-token': 'u-xaPqP6ZrF_bFjtxe9ebnJuByFykIfTuh9g2Zky',
          },
        }
      );

      console.log('Resposta da API ao atualizar status:', response.data);
    } catch (error) {
      console.error(`Erro ao atualizar o status ${isOnline ? 'online' : 'offline'}:`, error);
    }
  };

  const handleLogin = async (values) => {
    setLoading(true);
    try {
        const { data } = await axios.get('https://nocodb.nexusnerds.com.br/api/v2/tables/mjuogdam2c8ig6l/records', {
            params: {
                where: `(username,eq,${values.username})`,
            },
            headers: {
                'xc-token': 'u-xaPqP6ZrF_bFjtxe9ebnJuByFykIfTuh9g2Zky',
            },
        });

        console.log('Dados retornados do NocoDB:', data);

        if (data.list.length > 0) {
            const user = data.list[0];
            if (user.password === values.password) {
                const userProfile = {
                    id: user.Id, // Certifique-se de que "Id" está correto
                    name: user.name || user.username,
                    email: user.email,
                    profilePic: user.profilePicUrl,
                    Cargo1: user.Cargo1,
                    empresa: user.empresa,
                };

                console.log('userProfile criado:', userProfile);

                await updateOnlineStatus(userProfile, true); // Atualiza o status para online
                onLogin(userProfile); // Passa os dados do usuário para o componente pai

                // Adiciona a saudação aqui
                const greetingMessage = getGreetingMessage(userProfile.name || userProfile.username);
                message.success(greetingMessage);

                navigate('/home');
            } else {
                message.error('Senha incorreta.');
            }
        } else {
            message.error('Usuário não encontrado.');
        }
    } catch (error) {
        console.error('Erro na autenticação:', error);
        message.error('Erro na autenticação.');
    } finally {
        setLoading(false);
    }
};


  const handleLogout = async (user) => {
    try {
      console.log('Fazendo logout do usuário:', user);
      await updateOnlineStatus(user, false); // Atualiza o status para offline
    } catch (error) {
      console.error('Erro ao atualizar o status offline:', error);
    }
  };

  useEffect(() => {
    window.addEventListener('beforeunload', () => handleLogout(onLogin()));
    return () => {
      window.removeEventListener('beforeunload', () => handleLogout(onLogin()));
    };
  }, []);

  return (
    <div className="login-container" style={{ backgroundImage: `url(${background})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <div className="login-form-wrapper">
        <Card style={{ maxWidth: 400, margin: 'auto', padding: 20 }}>
          <Title level={3} style={{ textAlign: 'center' }}>Login</Title>
          <Form layout="vertical" onFinish={handleLogin}>
            <Form.Item
              label="Usuário"
              name="username"
              rules={[{ required: true, message: 'Por favor, insira seu usuário!' }]}
            >
              <Input placeholder="Digite seu usuário" />
            </Form.Item>
            <Form.Item
              label="Senha"
              name="password"
              rules={[{ required: true, message: 'Por favor, insira sua senha!' }]}
            >
              <Input.Password placeholder="Digite sua senha" />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" block loading={loading}>
                Entrar
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </div>
    </div>
  );
};

export default Login;
