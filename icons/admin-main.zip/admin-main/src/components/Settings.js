import React from 'react';

const Settings = () => <div>Settings Content</div>;

export default Settings;
