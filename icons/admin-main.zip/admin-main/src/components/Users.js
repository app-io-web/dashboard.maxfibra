import React from 'react';

const Users = () => <div>Users Content</div>;

export default Users;
