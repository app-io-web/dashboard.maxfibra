const firebaseConfig = {
    apiKey: "AIzaSyBZMctHaohP-HpzWqUZnDrTtW_-iCTSdvc",
    authDomain: "area-administrativa.firebaseapp.com",
    projectId: "area-administrativa",
    storageBucket: "area-administrativa.appspot.com",
    messagingSenderId: "503896293755",
    appId: "1:503896293755:web:20e80da8f68854512a7dde",
    measurementId: "G-ZEEK0RF1WT"
  };